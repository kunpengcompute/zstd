/**
 * @file zstar.h
 * @copyright Copyright (c) Huawei Technologies Co., Ltd. 2022-2023. All rights reserved.
 * @brief zstar External header file, include simple/stream compress and decompress function
 * @author Anonym
 * @date 2022-04-25
 * @version v0.1.0
 ********************************************************************************************
 * @par History
 * <table>
 * <tr><th>Date        <th>Version   <th>Author     <th>Description
 * <tr><td>2022-04-25  <td>0.1.0     <td>  <td>Init version
 * <tr><td>2022-09-29  <td>1.0.0     <td>  <td>add decompress function
 * <tr><td>2022-10-17  <td>1.1.0     <td>  <td>add stream function
 * </table>
 ********************************************************************************************
 */

/**
 * @defgroup  zstar
 */


#ifndef ZSTAR_H
#define ZSTAR_H

#ifdef __cplusplus
#include <cstddef>
#include <cstdint>
#else
#include <stddef.h>
#include <stdint.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @ingroup zstar
 * @brief 成功情况的返回值
 */
#define ZSTAR_OK 0

/**
 * @ingroup zstar
 * @brief 分步操作未结束，还需重复调用直到返回ZSTAR_OK
 */
#define ZSTAR_STEP_NOT_END 1

/**
 * @ingroup zstar
 * @brief 默认压缩等级
 */
#define ZSTAR_DEFAULT_COMPRESS_LEVEL 3

/**
 * @ingroup zstar
 * 错误码:输出缓冲区大小不足
 */
#define  ZSTAR_DST_CAPACITY_SMALL         (size_t)(-99)

/**
 * @ingroup zstar
 * 错误码:literals头字段错误
 */
#define  ZSTAR_INVALID_LITTYPE            (size_t)(-98)

/**
 * @ingroup zstar
 * 错误码:FSE压缩类型错误
 */
#define  ZSTAR_INVALID_FSE_TYPE           (size_t)(-97)

/**
 * @ingroup zstar
 * 错误码:非法的帧格式
 */
#define  ZSTAR_INVALID_FRAME              (size_t)(-96)

/**
 * @ingroup zstar
 * 错误码:非法的哈夫曼树
 */
#define  ZSTAR_INVALID_HUFF_TREE          (size_t)(-95)

/**
 * @ingroup zstar
 * 错误码:非法的压缩格式
 */
#define  ZSTAR_INVALID_FORMAT             (size_t)(-94)

/**
 * @ingroup zstar
 * 错误码:不支持字典功能
 */
#define  ZSTAR_NOT_SUPPORT_DICT           (size_t)(-93)

/**
 * @ingroup zstar
 * 错误码:校验和验证失败
 */
#define  ZSTAR_NOT_SUPPORT_CHECKSUM      (size_t)(-92)

/**
 * @ingroup zstar
 * 错误码:传入字典与字典库中该字典ID对应的字典不匹配
 */
#define  ZSTAR_DICT_NOT_MATCH      (size_t)(-89)

/**
 * @ingroup zstar
 * 错误码:未设置字典
 */
#define  ZSTAR_DICT_NOT_FOUND      (size_t)(-88)

/**
 * @ingroup zstar
 * 错误码:字典数量达到上限
 */
#define  ZSTAR_DICT_FULL           (size_t)(-87)

/**
 * @ingroup zstar
 * 错误码:采样不足
 */
#define  ZSTAR_COLLECT_NOT_ENOUGH  (size_t)(-86)

/**
 * @ingroup zstar
 * 错误码:并行化压缩/解压操作时子线程异常（已退出或者死循环）
 */
#define  ZSTAR_PARALL_THREAD_ABNORMAL  (size_t)(-85)

/**
 * @ingroup zstar
 * 错误码:输入数据未完全压缩
 */
#define  ZSTAR_INCOMPLETE_RES_USE         (size_t)(-4)

/**
 * @ingroup zstar
 * 错误码:安全函数操作失败
 */
#define  ZSTAR_SECUREC_ERROR              (size_t)(-3)

/**
 * @ingroup zstar
 * 错误码:内存分配失败
 */
#define  ZSTAR_MALLOC_FAILED              (size_t)(-2)

/**
 * @ingroup zstar
 * 错误码:入参非法
 */
#define  ZSTAR_INPUT_INVALID              (size_t)(-1)

/**
 * @ingroup zstar
 * @brief 支持并行化的环境变量
 * @attention
 * 设置该环境变量可以控制运行时的线程数量（包含主线程）。
 * 线程数量默认为0，即单线程模式。
 * 负数、非整形数为是无效值，线程数量设置为默认值0；超过最大限制17时，将线程数量设置为最大数值17。
 * 环境变量设置成功之后，动态修改不生效。
 */
#define ZSTAR_THREAD_NUM_ENV "ZSTAR_THREAD_NUM_ENV"

/**
 * @ingroup zstar
 * @brief 配置死循环检测超时时间
 * @attention
 * 设置该环境变量可以配置死循环检测超时时间，单位为秒s.
 * 执行压缩或者解压任务的主线程会检测子线程状态，如果子线程出现死循环且阻塞超过配置时间，则主线程会将
 * 子线程杀死，同时返回错误码ZSTAR_PARALL_THREAD_ABNORMAL(-85)，保证后续的任务可以正常执行。
 * 默认超时时间为300s，只接受大于0的整数，其余如负数、非整形数为是无效值，仍会使用默认值。
 * 环境变量设置成功之后，动态修改不生效。
 */
#define ZSTAR_THREAD_TIMEOUT_SEC_ENV "ZSTAR_THREAD_TIMEOUT_SEC_ENV"

/**
 * @ingroup zstar
 * @brief 配置决定是否开启并行化子线程常驻特性
 * @attention
 * 正常情况下线程常驻特性不开启，主线程需要绑定的子线程会在压缩/解压上下文初始化时创建，在上下文销毁时退出。
 * 如果开启该特性，子线程会在主线程第一次创建压缩或者解压上下文初始化时创建，并且不会随着上下文销毁而退出，仅会在主线程退出时跟随一起退出。
 * 开启该特性后可以进一步提升压缩解压性能，但是会使得进程内存在部分常驻线程，但这些线程会处于睡眠状态不会占用CPU.
 * 默认不开启并行化子线程特性，配置大于0的整数表示开启，其余如负数、非整形数为是无效值，不会开启该特性。
 * 环境变量设置成功之后，动态修改不生效。
 */
#define ZSTAR_THREAD_KEEP_ALIVE_ENV "ZSTAR_THREAD_KEEP_ALIVE_ENV"

/**
 * @ingroup zstar
 * @brief 设置并行特性子线程绑核数量
 * @attention
 * 未设置该环境变量，默认不开启绑核功能，线程使用默认调度方式。
 * 该环境配置大于0的整数表示绑核的数量，其余配置值都认为是无效值，不开启绑核功能。
 * 若设置的绑核数量超过当前环境最大cpu核数，则将绑核数量设置为当前环境最大cpu核数。
 * 绑核只绑定子线程，且绑核的序号从1开始。
 * 绑核时将子线程按照顺序绑到不同核上，若核全部绑满，则从头开始分配绑核序号。
 * 环境变量设置成功之后，动态修改不生效。
 */
#define ZSTAR_BOUNDING_CORE_NUM_ENV "ZSTAR_BOUNDING_CORE_NUM_ENV"

/**
 * @ingroup zstar
 * @brief 设置非流式压缩启用并行化所需数据的最小值
 * @attention
 * 未设置该环境变量，默认非流式压缩并行化需要数据大小为512KB。
 * 该环境配置大于0的整数表示非流式压缩并行化所需数据的大小；其余如负数、非整形数为是无效值，设置为默认大小。
 * 启用并行化所需数据大小的最小值由限制大小和线程数量中的最大值决定。
 * 环境变量设置成功之后，动态修改不生效。
 */
#define ZSTAR_THREAD_COMPRESS_LIMIT_ENV "ZSTAR_THREAD_COMPRESS_LIMIT_ENV"

/**
 * @ingroup zstar
 * @brief 用户提供的内存分配钩子函数，若未提供，则默认使用libc的malloc函数
 * @param size   [IN] 内存大小
 * @retval NULL  分配失败
 * @retval 非NULL  分配成功
 */
typedef void *(*ZstarMallocFunc)(size_t size);

/**
 * @ingroup zstar
 * @brief 用户提供的内存释放钩子函数，若未提供，则默认使用libc的free函数
 * @param addr   [IN] 内存地址
 * @retval 无
 */
typedef void (*ZstarFreeFunc)(void *addr);

/**
 * @ingroup zstar
 * @brief 内存分配释放钩子函数对
 */
typedef struct {
    ZstarMallocFunc zstarMallocFunc;    /**< 用户提供的内存分配钩子函数 */
    ZstarFreeFunc   zstarFreeFunc;      /**< 用户提供的内存释放钩子函数 */
} ZstarMallocFreeFunc;

/**
 * @ingroup zstar
 * @brief 压缩上下文句柄
 */
typedef struct TagZstarCCtx ZstarCCtx;

/**
 * @ingroup zstar
 * @brief 解压上下文句柄
 */
typedef struct TagZstarDCtx ZstarDCtx;

/********************************************Simple Compress Interface**********************************************/

/**
 * @ingroup zstar
 * @brief 预估压缩后大小
 * @par 描述: 根据待压缩数据的大小，计算压缩后数据需要的内存最大值
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param srcSize  [IN] 要压缩的数据大小，单位：字节
 * @retval >0 数据压缩后需提供的内存大小
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
size_t ZstarCompressBound(size_t srcSize);

/**
 * @ingroup zstar
 * @brief 压缩接口
 * @par 描述: 简单压缩接口，压缩器管理上下文。
 * @attention
 * 压缩等级越高，则压缩率越高，压缩速度越慢，反之同理。
 * 目前压缩等级仅支持1-4，指定未支持的压缩等级，则取默认压缩等级3。
 * 压缩数据输出内存块大小需大于等于#ZstarCompressBound的返回值。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * 规格限制：#ZstarCompressBound接口获取的输出缓冲区大小超过2G时，不支持压缩。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存分配释放，默认使用libc的内存接口malloc/free</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 输入数据越大，则耗时越多</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dst           [OUT] 压缩数据输出地址
 * @param dstSize       [IN] 输出地址大小，单位：字节
 * @param src           [IN] 输入数据起始地址
 * @param srcSize       [IN] 输入数据大小，单位：字节
 * @param level         [IN] 压缩等级
 * @retval >0   压缩后数据大小或错误码
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @see #ZstarMemHookRegister #ZstarCompressBound
 * @since V300R023C00
 */
size_t ZstarCompress(void *dst, size_t dstSize, const void *src, size_t srcSize, int level);

/**
 * @ingroup zstar
 * @brief 创建压缩上下文
 * @par 描述: 可用于连续的压缩，可指定内存分配释放接口
 * @attention
 * 若参数传空或函数对成员均为空则默认使用libc的内存接口malloc/free
 * @li Memory operation: alloc、free、size:
 * -# 本接口会申请上下文所需内存</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param func  [IN] 内存函数对
 * @retval NULL 创建失败，函数对其一为空或内存分配失败
 * @retval 非NULL 创建成功
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
ZstarCCtx *ZstarCCtxCreate(ZstarMallocFreeFunc *func);

/**
 * @ingroup zstar
 * @brief 带上下文的压缩接口
 * @par 描述: 简单压缩接口，用户自主管理上下文
 * @attention
 * 压缩等级越高，则压缩率越高，压缩速度越慢，反之同理。
 * 目前压缩等级仅支持1-4，指定未支持的压缩等级，则取默认压缩等级3。
 * 压缩数据输出内存块大小需大于等于#ZstarCompressBound的返回值。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * 规格限制：#ZstarCompressBound接口获取的输出缓冲区大小超过2G时，不支持压缩。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存分配释放</br>
 * @li Thread safe:
 * -# 相同上下文不支持多线程调用，不同上下文可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 输入数据越大，则耗时越多</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cCtx          [IN] 压缩上下文
 * @param dst           [OUT] 压缩数据输出地址
 * @param dstSize       [IN] 输出地址大小，单位：字节
 * @param src           [IN] 输入数据起始地址
 * @param srcSize       [IN] 输入数据大小，单位：字节
 * @param level         [IN] 压缩等级
 * @retval >0 压缩后数据大小或错误码
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @see #ZstarCCtxCreate
 * @since V300R023C00
 */
size_t ZstarCompressCCtx(ZstarCCtx *cCtx, void *dst, size_t dstSize, const void *src, size_t srcSize, int level);

/**
 * @ingroup zstar
 * @brief 释放压缩上下文
 * @par 描述: 释放压缩上下文
 * @attention
 * 与#ZstarCCtxCreate匹配使用
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存释放</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cCtx  [IN] 压缩上下文
 * @retval 无
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @see #ZstarCCtxCreate
 * @since V300R023C00
 */
void ZstarCCtxFree(ZstarCCtx *cCtx);

/********************************************Simple Decompress Interface**********************************************/

/**
 * @ingroup zstar
 * @brief 获取解压缩数据大小
 * @par 描述: 从帧头获取输入数据解压缩后所需空间大小
 * @attention
 * 输入数据必须是包含帧结构的有效zstar结构数据。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param src       [IN] 有效zstar压缩格式数据地址
 * @param srcSize   [IN] 输入数据大小，单位：字节
 * @retval >=0 解压数据的大小
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
unsigned long long ZstarFrameContentSizeGet(const void *src, size_t srcSize);

/**
 * @ingroup zstar
 * @brief 获取完整帧大小
 * @par 描述: 从输入数据中获取完整帧的大小
 * @attention
 * 输入数据src必须是有效zstar格式并应指向帧的开始。
 * 输入数据大小srcSize应大于等于帧大小。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param src       [IN] 有效zstar压缩格式数据地址
 * @param srcSize   [IN] 输入数据大小，单位：字节
 * @retval >0 完整帧压缩大小
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
size_t ZstarFrameCompressedSizeGet(const void *src, size_t srcSize);

/**
 * @ingroup zstar
 * @brief 解压接口
 * @par 描述: 简单解压接口，压缩器管理上下文。
 * @attention
 * 解压数据输出内存块大小需大于等于#ZstarFrameContentSizeGet的返回值。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * 规格限制：#ZstarFrameContentSizeGet接口获取的输出缓冲区大小超过2G时，不支持解压。
 * 若解压带校验和的压缩内容，则会跳过校验和内容正常解压。
 * 本接口仅支持单帧解压，多帧解压需结合#ZstarFrameCompressedSizeGet接口使用。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存分配释放，默认使用libc的内存接口malloc/free</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 输入数据越大，则耗时越多</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dst           [OUT] 解压数据输出地址
 * @param dstSize       [IN] 输出地址大小，单位：字节
 * @param src           [IN] 有效压缩数据起始地址
 * @param srcSize       [IN] 输入数据大小，单位：字节
 * @retval  >=0  解压后数据大小或错误码
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @see #ZstarFrameContentSizeGet
 * @since V300R023C00
 */
size_t ZstarDecompress(void *dst, size_t dstSize, const void *src, size_t srcSize);

/**
 * @ingroup zstar
 * @brief 创建解压上下文
 * @par 描述: 可用于连续的解压，可指定内存分配释放接口
 * @attention
 * 若参数传空或函数对成员均为空则默认使用libc的内存接口malloc/free。
 * @li Memory operation: alloc、free、size:
 * -# 本接口会申请上下文所需内存</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param func  [IN] 内存函数对
 * @retval NULL 创建失败，函数对其一为空或内存分配失败
 * @retval 非NULL 创建成功
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
ZstarDCtx *ZstarDCtxCreate(ZstarMallocFreeFunc *func);

/**
 * @ingroup zstar
 * @brief 带上下文的解压接口
 * @par 描述: 简单解压接口，用户自主管理上下文
 * @attention
 * 解压数据输出内存块大小需大于等于#ZstarFrameContentSizeGet的返回值。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * 规格限制：#ZstarFrameContentSizeGet接口获取的输出缓冲区大小超过2G时，不支持解压。
 * 若解压带校验和的压缩内容，则会跳过校验和内容正常解压。
 * 本接口仅支持单帧解压，多帧解压需结合#ZstarFrameCompressedSizeGet接口使用。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存分配释放</br>
 * @li Thread safe:
 * -# 相同上下文不支持多线程调用，不同上下文可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 输入数据越大，则耗时越多</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dCtx          [IN] 解压上下文
 * @param dst           [OUT] 解压数据输出地址
 * @param dstSize       [IN] 输出地址大小，单位：字节
 * @param src           [IN] 有效压缩数据起始地址
 * @param srcSize       [IN] 输入数据大小，单位：字节
 * @retval  >=0  解压后数据大小或错误码
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @see #ZstarDCtxCreate
 * @since V300R023C00
 */
size_t ZstarDecompressDCtx(ZstarDCtx *dCtx, void *dst, size_t dstSize, const void *src, size_t srcSize);

/**
 * @ingroup zstar
 * @brief 释放解压上下文
 * @par 描述: 释放解压上下文
 * @attention
 * 与#ZstarDCtxCreate配对使用。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存释放</br>
 * @li Thread safe:
 * -# 不同上下文支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dCtx  [IN] 解压上下文
 * @retval 无
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @see #ZstarDCtxCreate
 * @since V300R023C00
 */
void ZstarDCtxFree(ZstarDCtx *dCtx);

/********************************************Dictionary Interface**********************************************/

/**
 * @ingroup zstar
 * @brief 添加压缩字典
 * @par 描述: 添加一个字典，可以用于给定压缩等级的压缩功能
 * @attention
 * 1、根据RFC8878标准：在私有环境中，可以使用任何字典ID。但是，对于需在公共空间中发布字典，
 *    字典ID<=32767和字典ID>=(1<<31)的范围仅供已在IANA注册的字典使用。
 * 2、dictSize需大于0字节，小等于2G。
 * 3、当前支持压缩等级1/2/3/4。
 * 4、当前支持最多创建16个不同字典ID的字典。
 * 5、向已添加字典增加新的压缩等级时，dict可以传NULL。
 * 6、向已添加字典增加新的压缩等级时，func函数不会刷新，将使用第一次添加该字典时传入的func函数。
 * 7、字典ID为0时将尝试使用dict中的字典ID，dict中无字典ID信息时返回失败。
 *    注意使用该方式添加字典时，需确认dict中包含有字典ID信息，且保存dict中字典ID值已便压缩或删除时使用。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存申请</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dict     [IN] 字典数据起始地址
 * @param dictSize [IN] 字典数据大小，单位：字节
 * @param func     [IN] 内存分配释放钩子函数对
 * @param dictID   [IN] 字典ID
 * @param level    [IN] 压缩等级
 * @retval 0 创建成功
 * @retval 错误码 创建失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarAddCompressDict(const void *dict, size_t dictSize, ZstarMallocFreeFunc *func, uint32_t dictID, int level);

/**
 * @ingroup zstar
 * @brief 字典压缩接口
 * @par 描述: 字典压缩接口，用户自主管理上下文
 * @attention
 * 1、dictID及level对应的字典需使用相关接口添加过。
 * 2、dictID为0时使用非字典模式压缩。
 * 3、压缩等级越高，则压缩率越高，压缩速度越慢，反之同理。
 * 目前压缩等级仅支持1-4，指定未支持的压缩等级，则取默认压缩等级3。
 * 压缩数据输出内存块大小需大于等于#ZstarCompressBound的返回值。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * 规格限制：#ZstarCompressBound接口获取的输出缓冲区大小超过2G时，不支持压缩。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存申请</br>
 * @li Thread safe:
 * -# 相同上下文不支持多线程调用，不同上下文可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 输入数据越大，则耗时越多</br>
 * -# 输入level越高，则耗时越多</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cCtx          [IN] 压缩上下文
 * @param dst           [OUT] 压缩数据输出地址
 * @param dstSize       [IN] 输出地址大小，单位：字节
 * @param src           [IN] 输入数据起始地址
 * @param srcSize       [IN] 输入数据大小，单位：字节
 * @param dictID        [IN] 字典ID
 * @param level         [IN] 压缩等级
 * @retval 压缩后数据大小或错误码
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarDictCompressCCtx(ZstarCCtx *cCtx, void *dst, size_t dstSize, const void *src,
                             size_t srcSize, uint32_t dictID, int level);

/**
 * @ingroup zstar
 * @brief 删除压缩字典
 * @par 描述: 使给定字典ID的字典不再支持压缩功能
 * @attention
 * 1、dictID为0时将释放所有压缩字典。
 * 2、dictID不为0，level为0时，将释放dictID对应所有压缩等级的字典。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存释放</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictID  [IN] 字典ID
 * @param level   [IN] 压缩等级
 * @retval 0 删除成功
 * @retval 错误码 删除失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarDeleteCompressDict(uint32_t dictID, uint32_t level);

/**
 * @ingroup zstar
 * @brief 添加解压字典
 * @par 描述: 添加给定字典ID的字典，可以用于解压功能
 * @attention
 * 1、根据RFC8878标准：在私有环境中，可以使用任何字典ID。但是，对于需在公共空间中发布字典，
 *    字典ID<=32767和字典ID>=(1<<31)的范围仅供已在IANA注册的字典使用。
 * 2、dictSize需大于0字节，小等于2G。
 * 3、当前支持最多创建16个不同字典ID的字典。
 * 4、若该字典ID已经添加过压缩字典，dict、dictSize、func都需与添加压缩字典时传入的参数一致。
 * 5、字典ID为0时将尝试使用dict中的字典ID，dict中无字典ID信息时返回失败。
 *    注意使用该方式添加字典时，需确认dict中包含有字典ID信息，且保存dict中字典ID值已便解压或删除时使用。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存申请</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dict     [IN] 字典数据起始地址
 * @param dictSize [IN] 字典数据大小，单位：字节
 * @param func     [IN] 内存分配释放钩子函数对
 * @param dictID   [IN] 字典ID
 * @retval 0 创建成功
 * @retval 错误码 创建失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarAddDecompressDict(const void *dict, size_t dictSize, ZstarMallocFreeFunc *func, uint32_t dictID);

/**
 * @ingroup zstar
 * @brief 删除解压字典
 * @par 描述: 使给定字典ID对应的字典不再支持解压功能
 * @attention
 * 1、与#ZstarAddDecompressDict配对使用。
 * 2、dictID为0时将释放所有解压字典字典。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存释放</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictID  [IN] 字典ID
 * @retval 0 删除成功
 * @retval 错误码 删除失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarDeleteDecompressDict(uint32_t dictID);

/**
 * @ingroup zstar
 * @brief 向zstar添加字典
 * @par 描述: 添加一个字典，可以用于解压功能和给定压缩等级的压缩功能
 * @attention
 * 1、根据RFC8878标准：在私有环境中，可以使用任何字典ID。但是，对于需在公共空间中发布字典，
 *    字典ID<=32767和字典ID>=(1<<31)的范围仅供已在IANA注册的字典使用。
 * 2、dictSize需大于0字节，小等于2G。
 * 3、当前支持最多创建16个不同字典ID的字典。
 * 4、若该字典ID已经添加过字典，dict、dictSize、func都需与之前添加字典时传入的参数一致。
 * 5、字典ID为0时将尝试使用dict中的字典ID，dict中无字典ID信息时返回失败。
 *    注意使用该方式添加字典时，需确认dict中包含有字典ID信息，且保存dict中字典ID值已便压缩、解压或删除时使用。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存申请</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dict     [IN] 字典数据起始地址
 * @param dictSize [IN] 字典数据大小，单位：字节
 * @param func     [IN] 内存分配释放钩子函数对
 * @param dictID   [IN] 字典ID
 * @param level    [IN] 压缩等级
 * @retval 0 创建成功
 * @retval 错误码 创建失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarAddDict(const void *dict, size_t dictSize, ZstarMallocFreeFunc *func, uint32_t dictID, int level);

/**
 * @ingroup zstar
 * @brief 删除字典
 * @par 描述: 删除给定字典ID对应的字典
 * @attention
 * 1、dictID为0时将释放所有字典。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存释放</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictID  [IN] 字典ID
 * @retval 0 删除成功
 * @retval 错误码 删除失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarDeleteDict(uint32_t dictID);

/**
 * @ingroup zstar
 * @brief 获取字典ID数组
 * @par 描述: 获取所有已添加的字典ID
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictIDArray [IN|OUT] 字典ID数组输出地址
 * @param arrayLen    [IN] 字典ID数组长度
 * @retval 已添加的字典数量或错误码
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarGetAddedDictsID(uint32_t *dictIDArray, size_t arrayLen);

/**
 * @ingroup zstar
 * @brief 字典信息
 */
typedef struct {
    const void *dict;             /**< 内部的字典buff */
    size_t dictSize;              /**< 字典buff大小 */
    uint32_t dictID;              /**< 字典ID */
    uint8_t level[22];            /**< 已添加的压缩等级，0表示未添加，非0表示已添加
                                    *  注意level[0]表示压缩等级1，以此类推 */
    uint8_t decompressDict;       /**< 是否已添加解压字典，0表示未添加，非0表示已添加 */
    uint8_t reserved;             /**< 占位字段，补齐4字节对齐 */
} ZstarDictInfo;

/**
 * @ingroup zstar
 * @brief 获取字典信息
 * @par 描述: 获取给定字典ID对应的字典的相关信息
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictID      [IN] 待查询的字典ID
 * @param dictInfo    [IN] 字典ID信息
 * @retval 0 查询成功
 * @retval 错误码 查询失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C10
 */
size_t ZstarGetDictInfo(uint32_t dictID, ZstarDictInfo *dictInfo);

/****************************************Dictionary Builder Interface**********************************************/

/**
 * @ingroup zstar
 * @brief 字典构建器句柄
 */
typedef struct TagZstarDictBuilder ZstarDictBuilder;

/**
 * @ingroup zstar
 * @brief 创建字典训练器
 * @par 描述: 创建字典训练器，可指定内存分配释放接口
 * @attention
 * 若参数传空或函数对成员均为空则默认使用libc的内存接口malloc/free
 * @li Memory operation: alloc、free、size:
 * -# 本接口会申请上下文所需内存</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param func          [IN] 内存申请释放函数
 * @retval NULL 创建失败，函数对其一为空或内存分配失败
 * @retval 非NULL 创建成功
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
ZstarDictBuilder *ZstarDictBuilderCreate(ZstarMallocFreeFunc *func);

/**
 * @ingroup zstar
 * @brief 字典采集模式
 */
typedef enum {
    ZSTAR_COLLECT_UNTIL_FULL = 0, /**< 开始采集，直到缓冲区满后不再采集 */
    ZSTAR_COLLECT_AUTO_TRAIN,     /**< 开始采集，直到缓冲区满后自动训练 */
    ZSTAR_COLLECT_PAUSE,          /**< 暂停采集功能 */
    ZSTAR_COLLECT_CLEAN,          /**< 停止采集并清理缓冲区 */
} ZstarDictBuilderCollectMode;

/**
 * @ingroup zstar
 * @brief 字典训练模式
 */
typedef enum {
    ZSTAR_SINGLE_STEP = 0,        /**< 单线程单步处理 */
    ZSTAR_MULTI_STEP,             /**< 单线程分多步处理 */
} ZstarDictBuilderTrainMode;

/**
 * @ingroup zstar
 * @brief 样本来源类型
 */
typedef enum {
    ZSTAR_SAMPLE_ORIGINAL = 0,    /**< 采集样本为原始数据 */
    ZSTAR_SAMPLE_MIDDLE,          /**< 采集样本为中间字典 */
} ZstarDictBuilderSampleType;

/**
 * @ingroup zstar
 * @brief 训练目标类型
 */
typedef enum {
    ZSTAR_TRAIN_MIDDLE_DICT = 0,  /**< 训练中间字典 */
    ZSTAR_TRAIN_FINAL_DICT,       /**< 训练最终字典 */
} ZstarDictBuilderTrainObj;

/**
 * @ingroup zstar
 * @brief 字典构建器设置参数
 */
typedef struct {
    ZstarDictBuilderTrainMode trainMode;    /**< 训练方式 */
    ZstarDictBuilderSampleType sampleType;  /**< 样本来源，此参数设置后不允许修改 */
    ZstarDictBuilderTrainObj objective;     /**< 训练目标 */
    uint32_t interval;              /**< 采样间隔次数 */
    size_t bufSize;                 /**< 单字典缓冲区大小设置，不可小于500字节, 且不可小于blockSize的10倍 */
    size_t maxNum;                  /**< 单字典ID的最大采集数量，传0时不限制 */
    size_t minSize;                 /**< 开始训练时单字典ID的缓冲区最小已缓存大小，传0时不限制 */
    size_t minNum;                  /**< 开始训练时单字典ID的最小采集数量，传0时不限制 */
    size_t blockSize;               /**< 指定训练时块大小，可设置范围为50-2048，超出范围时将增加耗时自动寻找最优块大小 */
    int level;                      /**< 此字典建议的压缩等级，实际使用的压缩等级与此次建议的压缩等级一致时压缩效果最好 */
    uint32_t reserve[3];            /**< 保留字段，需设为0 */
} ZstarDictBuilderParams;

/**
 * @ingroup zstar
 * @brief 字典训练器配置函数
 * @par 描述: 配置字典训练器采集参数、训练参数、暂停采集等信息
 * @attention
 * ZstarDictBuilderCollectMode为ZSTAR_COLLECT_PAUSE或ZSTAR_COLLECT_CLEAN时，params可以传NULL。
 * 对于同一Type的字典允许重复调用此函数来修改参数，训练开始后不允许修改
 * @li Memory operation: alloc、free、size:
 * -# 本接口会申请训练器所需内存</br>
 * @li Thread safe:
 * -# 相同字典训练器不支持多线程调用，不同字典训练器可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictBuilder   [IN] 字典训练器
 * @param collectMode   [IN] 采集方式
 * @param dictType      [IN] 字典类型
 * @param params        [IN] 设置参数，仅ZstarDictBuilderCollectMode为START_UNTIL_FULL或者START_AUTO_TARIN时才需要传入该参数
 * @retval ZSTAR_OK 创建成功
 * @retval 错误码 创建失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
size_t ZstarDictBuilderSet(ZstarDictBuilder *dictBuilder, ZstarDictBuilderCollectMode collectMode,
    uint32_t dictType, ZstarDictBuilderParams *params);

/**
 * @ingroup zstar
 * @brief 字典训练器采集接口
 * @par 描述: 向字典训练器中添加样本
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 相同字典训练器不支持多线程调用，不同字典训练器可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 若ZstarDictBuilderSet接口设置采集模式为ZSTAR_COLLECT_AUTO_TRAIN，缓冲区满时增加一次清理缓冲区的耗时</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictBuilder  [IN] 字典训练器
 * @param src          [IN] 此次采集的样本
 * @param srcSize      [IN] 此次采集的样本大小
 * @param dictType     [IN] 字典类型
 * @retval ZSTAR_OK 采集成功
 * @retval 错误码 采集失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
size_t ZstarDictBuilderCollect(ZstarDictBuilder *dictBuilder, const void *src, size_t srcSize, uint32_t dictType);

/**
 * @ingroup zstar
 * @brief 字典训练接口
 * @par 描述: 字典训练接口，使用字典训练器中采集好的数据开始训练
 * @attention
 * 调用此接口开始训练时，采集模式会自动切换为ZSTAR_COLLECT_PAUSE，在训练结束前不允许重新打开采集功能
 * 训练成功后，将自动清理缓冲区
 * 字典大小不能超过2G
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 相同字典训练器不支持多线程调用，不同字典训练器可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 采集的数据越多，则耗时越多</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictBuilder   [IN] 字典训练器
 * @param dst           [IN] 输出缓冲区
 * @param dstSize       [IN] 输出缓冲区大小
 * @param dictType      [IN] 字典分类ID
 * @retval ZSTAR_STEP_NOT_END 训练未完成，还需继续调用当前接口继续下一步训练
 * @retval 错误码 训练失败
 * @retval 其他 训练成功，返回字典大小
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
size_t ZstarDictBuilderTrain(ZstarDictBuilder *dictBuilder, void *dst, size_t dstSize,
    uint32_t dictType);

/**
 * @ingroup zstar
 * @brief 字典采集状态信息
 */
typedef struct {
    size_t collectSize;			   /**< 已采集的样本总大小 */
    size_t sampleNum;			   /**< 已采集的样本数量 */
    uint32_t dictType;			   /**< 字典分类ID */
    ZstarDictBuilderCollectMode collectMode; /**< 采集模式 */
    ZstarDictBuilderParams params; /**< 字典构建器设置参数 */
} ZstarCollectInfo;

/**
 * @ingroup zstar
 * @brief 采集信息查询接口
 * @par 描述: 从字典训练器中查询采集参数等、已采集大小等信息
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 相同字典训练器不支持多线程调用，不同字典训练器可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictBuilder   [IN] 字典训练器
 * @param dictType      [IN] 字典分类ID
 * @param collectInfo   [IN|OUT] 采集状态信息
 * @retval ZSTAR_OK 成功获取到采集信息
 * @retval 错误码 获取失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
size_t ZstarDictBuilderGetCollectInfo(ZstarDictBuilder *dictBuilder, uint32_t dictType, ZstarCollectInfo *collectInfo);

/**
 * @ingroup zstar
 * @brief 释放字典训练器
 * @par 描述: 清理字段训练器占用的内存资源
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存释放</br>
 * @li Thread safe:
 * -# 相同字典训练器不支持多线程调用，不同字典训练器可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dictBuilder   [IN] 字典训练器
 * @retval 无
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
void ZstarDictBuilderFree(ZstarDictBuilder *dictBuilder);

/**
 * @ingroup zstar
 * @brief 字典训练器绑定接口
 * @par 描述: 在压缩上下文中绑定字典训练器
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 本接口会申请训练器所需内存, 采集模式为ZSTAR_COLLECT_CLEAN时涉及内存释放</br>
 * @li Thread safe:
 * -# 相同上下文不支持多线程调用，不同上下文可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cCtx          [IN] 压缩上下文
 * @param dictBuilder   [IN] 字典训练器
 * @retval ZSTAR_OK 绑定成功
 * @retval 错误码 cCtx为NULL
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
size_t ZstarCCtxDictBuilderSet(ZstarCCtx *cCtx, ZstarDictBuilder *dictBuilder);

/**
 * @ingroup zstar
 * @brief 字典训练器获取接口
 * @par 描述: 从压缩上下文中获取字典训练器
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 本接口会申请训练器所需内存, 采集模式为ZSTAR_COLLECT_CLEAN时涉及内存释放</br>
 * @li Thread safe:
 * -# 相同上下文不支持多线程调用，不同上下文可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cCtx          [IN] 压缩上下文
 * @retval 非NULL 返回压缩上下文中绑定的字典训练器
 * @retval NULL 压缩上下文为NULL
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
ZstarDictBuilder *ZstarCCtxDictBuilderGet(ZstarCCtx *cCtx);

/**
 * @ingroup zstar
 * @brief 采集压缩参数
 */
typedef struct {
    ZstarCCtx *cCtx;    /**< 压缩上下文 */
    uint32_t dictID;    /**< 当前压缩使用的字典ID，字典ID为0时不使用字典进行压缩 */
    uint32_t dictType;  /**< 字典类别 */
    int level;          /**< 压缩等级 */
    int reserve;        /**< 保留字段 */
} ZstarCollectCompressParams;

/**
 * @ingroup zstar
 * @brief 采集压缩接口
 * @par 描述: 能自动采集的压缩接口，支持字典压缩，配合ZstarCCtxSetDictBuilder使用可以在压缩时自动采样
 * @attention
 * 1、param中dictID及level对应的字典需使用相关接口添加过。
 * 2、param中dictID为0时使用非字典模式压缩。
 * 3、param中压缩等级越高，则压缩率越高，压缩速度越慢，反之同理。
 * 目前压缩等级仅支持1-4，指定未支持的压缩等级，则取默认压缩等级3。
 * 压缩数据输出内存块大小需大于等于#ZstarCompressBound的返回值。
 * 传入的内存地址及其内存大小必须匹配，否则可能造成越界访问。
 * 规格限制：#ZstarCompressBound接口获取的输出缓冲区大小超过2G时，不支持压缩。
 * @li Memory operation: alloc、free、size:
 * -# 涉及内存申请</br>
 * @li Thread safe:
 * -# 相同上下文不支持多线程调用，不同上下文可多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 输入数据越大，则耗时越多</br>
 * -# 输入level越高，则耗时越多</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dst           [OUT] 压缩数据输出地址
 * @param dictSize      [IN] 输出地址大小，单位：字节
 * @param src           [IN] 输入数据起始地址
 * @param srcSize       [IN] 输入数据大小，单位：字节
 * @param param         [IN] 压缩参数
 * @retval >0 压缩后数据大小或错误码
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C10
 */
size_t ZstarCollectCompress(void *dst, size_t dstSize, const void *src, size_t srcSize,
    ZstarCollectCompressParams *param);

/*********************************************Error Interface**********************************************/

/**
 * @ingroup zstar
 * @brief 检查压缩器的返回值是否为错误码
 * @par 描述: 检查压缩器的返回值是否为错误码
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param result  [IN] 压缩器返回值
 * @retval !=ZSTAR_OK 结果错误
 * @retval ==ZSTAR_OK 无错误
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
uint32_t ZstarIsError(size_t result);

/**
 * @ingroup zstar
 * @brief 提供错误码对应的错误信息
 * @par 描述: 提供错误码对应的错误信息
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 线程安全，支持多线程调用</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param errCode  [IN] 错误码
 * @retval 字符串 错误信息
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
const char *ZstarErrInfoGet(size_t errCode);

/*********************************************Public Interface**********************************************/

/**
 * @ingroup zstar
 * @brief 日志记录钩子
 * @attention 由于压缩、解压接口支持并发，所以此接口实现须用户保证支持并发。
 * @param  message  [IN] 日志信息
 * @param  size     [IN] 日志长度
 */
typedef void (*ZstarLogFunc)(const char *message, size_t size);

/**
 * @ingroup zstar
 * @brief 日志钩子注册接口
 * @par 描述: 用户可以自定义日志输出，默认不记录日志。
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 不支持并发，以最后一次注册为准</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param func     [IN] 日志记录钩子
 * @retval 无
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R023C00
 */
void ZstarLogRegister(ZstarLogFunc func);

/********************************************Stream Compress Interface**********************************************/
/**
 * @ingroup zstar
 * @brief 记录输入数据的缓冲区的结构体
 */
typedef struct TagZstarInBuffer {
    const void *src; /**< 输入缓冲区的起始地址 */
    size_t size; /**< 输入缓冲区的大小 */
    size_t pos; /**< 输入缓冲区当前待读取的位置 */
} ZstarInBuffer;

/**
 * @ingroup zstar
 * @brief 记录保存输出数据的缓冲区的结构体
 */
typedef struct TagZstarOutBuffer {
    void *dst; /**< 输出缓冲区的起始地址 */
    size_t size; /**< 输出缓冲区的大小 */
    size_t pos; /**< 将要写入到输出缓冲区的位置 */
} ZstarOutBuffer;

/**
 * @ingroup zstar
 * @brief 压缩流控制信息的结构体
 */
typedef struct TagZstarCCtx ZstarCStream;

/**
 * @ingroup zstar
 * @brief Zstar流式压缩上下文创建接口
 * @par 描述: 用户可以配置内存申请释放钩子，并创建返回Zstar流式压缩上下文
 * @attention 如果输入是NULL，或者钩子都为NULL，则会调用libc的内存功能
 * @li Memory operation: alloc、free、size:
 * -# 涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param func     [IN] 内存分配释放钩子函数对
 * @retval NULL 创建失败
 * @retval 非NULL 创建成功
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
ZstarCStream *ZstarCStreamCreate(ZstarMallocFreeFunc *func);

/**
 * @ingroup zstar
 * @brief Zstar流式压缩上下文初始化接口
 * @par 描述: 根据压缩等级，对流式压缩上下文及其内部结构体进行初始化
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cStream   [IN] 流式压缩上下文
 * @param level     [IN] 压缩等级
 * @retval ZSTAR_OK 初始化成功
 * @retval 非ZSTAR_OK 初始化失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
size_t ZstarCStreamInit(ZstarCStream *cStream, int level);

/**
 * @ingroup zstar
 * @brief Zstar流式压缩接口
 * @par 描述: 进行流式压缩，用户需要自己配置管理传入的inBuffer和outBuffer
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cStream   [IN] 流式压缩上下文
 * @param outBuffer  [IN] 用于存储压缩数据和当前压缩位置
 * @param inBuffer   [IN] 用于加载当前待压缩数据及其位置
 * @retval errno 压缩失败
 * @retval 非errno 压缩成功
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
size_t ZstarCompressStream(ZstarCStream *cStream, ZstarOutBuffer *outBuffer, ZstarInBuffer *inBuffer);

/**
 * @ingroup zstar
 * @brief Zstar流式压缩截止接口
 * @par 描述: 终止流式压缩，并添加末尾信息
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cStream   [IN] 流式压缩上下文
 * @param outBuffer  [IN] 用于存储压缩数据和当前压缩位置
 * @retval errno 截止失败
 * @retval ZSTAR_OK 截止成功
 * @retval 其他 剩余未写入的大小
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
size_t ZstarEndStream(ZstarCStream *cStream, ZstarOutBuffer *outBuffer);

/**
 * @ingroup zstar
 * @brief Zstar流式压缩上下文释放接口
 * @par 描述: 释放Zstar流式压缩上下文
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param cStream   [IN] 流式压缩上下文
 * @retval 无
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
void ZstarCStreamFree(ZstarCStream *cStream);

/********************************************Stream Decompress Interface**********************************************/

/**
 * @ingroup zstar
 * @brief 解压流控制信息的结构体
 */
typedef struct TagZstarDCtx ZstarDStream;

/**
 * @ingroup zstar
 * @brief Zstar流式解压缩上下文创建接口
 * @par 描述: 用户可以配置内存申请释放钩子，并创建返回Zstar流式解压上下文
 * @attention 如果输入是NULL，或者钩子都为NULL，则会调用libc的内存功能
 * @li Memory operation: alloc、free、size:
 * -# 涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param func     [IN] 内存分配释放钩子函数对
 * @retval NULL 创建失败
 * @retval 非NULL 创建成功
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
ZstarDStream *ZstarDStreamCreate(ZstarMallocFreeFunc *func);

/**
 * @ingroup zstar
 * @brief Zstar流式解压缩上下文初始化接口
 * @par 描述: 对流式解压上下文及其内部结构体进行初始化
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dStream   [IN] 流式解压上下文
 * @retval ZSTAR_OK 初始化成功
 * @retval 非ZSTAR_OK 初始化失败
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
size_t ZstarDStreamInit(ZstarDStream *dStream);

/**
 * @ingroup zstar
 * @brief Zstar流式解压缩接口
 * @par 描述: 进行流式解压，用户需要自己配置管理传入的inBuffer和outBuffer
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 不涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dStream    [IN] 流式解压上下文
 * @param outBuffer  [IN] 用于存储解压数据和当前解压位置
 * @param inBuffer   [IN] 用于加载当前待解压数据及其位置
 * @retval errno 解压失败
 * @retval 非errno 解压成功
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
size_t ZstarDecompressStream(ZstarDStream *dStream, ZstarOutBuffer *outBuffer, ZstarInBuffer *inBuffer);

/**
 * @ingroup zstar
 * @brief Zstar流式解压缩上下文释放接口
 * @par 描述: 释放Zstar流式解压缩上下文
 * @attention
 * @li Memory operation: alloc、free、size:
 * -# 涉及</br>
 * @li Thread safe:
 * -# 不支持并发</br>
 * @li OS/CPU difference:
 * -# 不涉及</br>
 * @li Time consuming:
 * -# 不涉及</br>
 * @li Permission Required:
 * -# 该接口不需要capbility</br>
 * @param dStream   [IN] 流式解压缩上下文
 * @retval 无
 * @par 依赖: 如下
 * @li zstar：该接口所属的开发包。
 * @li zstar.h：该接口声明所在的头文件。
 * @since V300R024C00
 */
void ZstarDStreamFree(ZstarDStream *dStream);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
